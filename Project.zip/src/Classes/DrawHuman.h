#pragma once
#include "../Main.h"

class DrawHuman
{
public:
	static void draw(float fov, float theta, GLuint modelMatLoc, GLuint projMatLoc);
};
